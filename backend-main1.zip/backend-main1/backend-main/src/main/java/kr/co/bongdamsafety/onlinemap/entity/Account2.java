package kr.co.bongdamsafety.onlinemap.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import java.sql.Timestamp;
import lombok.Generated;

@Entity
public class Account2 {
    @Id
    private String id;
    @Column(
            nullable = false,
            columnDefinition = "char(128)"
    )
    private String password;
    @Column(
            nullable = false,
            length = 4000
    )
    private String name;
    @Column(
            nullable = false
    )
    private int permlevel;
    @Column(
            length = 4000
    )
    private String content;
    @Column(
            updatable = false
    )
    private Timestamp date_created;
    @Column
    private Timestamp date_edited;
    @ManyToOne
    @JoinColumn(
            name = "account_id_created_this",
            referencedColumnName = "id"
    )
    private Account account_created_this;

    @PrePersist
    public void onCreate() {
        this.date_created = new Timestamp(System.currentTimeMillis());
    }

    @PreUpdate
    public void onUpdate() {
        this.date_edited = new Timestamp(System.currentTimeMillis());
    }

    @Generated
    public Account2(final String id, final String password, final String name, final int permlevel, final String content, final Timestamp date_created, final Timestamp date_edited, final Account account_created_this) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.permlevel = permlevel;
        this.content = content;
        this.date_created = date_created;
        this.date_edited = date_edited;
        this.account_created_this = account_created_this;
    }

    @Generated
    public Account2() {
    }

    @Generated
    public String toString() {
        String var10000 = this.getId();
        return "Account(id=" + var10000 + ", password=" + this.getPassword() + ", name=" + this.getName() + ", permlevel=" + this.getPermlevel() + ", content=" + this.getContent() + ", date_created=" + this.getDate_created() + ", date_edited=" + this.getDate_edited() + ", account_created_this=" + this.getAccount_created_this() + ")";
    }

    @Generated
    public String getId() {
        return this.id;
    }

    @Generated
    public String getPassword() {
        return this.password;
    }

    @Generated
    public String getName() {
        return this.name;
    }

    @Generated
    public int getPermlevel() {
        return this.permlevel;
    }

    @Generated
    public String getContent() {
        return this.content;
    }

    @Generated
    public Timestamp getDate_created() {
        return this.date_created;
    }

    @Generated
    public Timestamp getDate_edited() {
        return this.date_edited;
    }

    @Generated
    public Account getAccount_created_this() {
        return this.account_created_this;
    }
}
