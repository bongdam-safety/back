package kr.co.bongdamsafety.onlinemap.service;

import org.springframework.stereotype.Service;

@Service
public class RootPageHelloWorldService {
    public String helloWorld() {
        return "Hello world!"; // Hello world! 반환
    }
}
