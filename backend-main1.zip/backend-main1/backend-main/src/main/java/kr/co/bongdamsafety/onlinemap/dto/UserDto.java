package kr.co.bongdamsafety.onlinemap.dto;

import lombok.Generated;

public class UserDto {
    private String email; // 사용자 이메일 필드
    private String password; // 비밀번호 필드

    // 기본 생성자
    public UserDto() {
    }

    // 이메일 getter 메소드
    public String getEmail() {
        return this.email;
    }

    // 비밀번호 getter 메소드
    public String getPassword() {
        return this.password;
    }

    // 이메일 setter 메소드
    public void setEmail(final String email) {
        this.email = email;
    }

    // 비밀번호 setter 메소드
    public void setPassword(final String password) {
        this.password = password;
    }
}